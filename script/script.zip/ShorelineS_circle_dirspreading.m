addpath(genpath('..\functions_202201\'));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% MODEL INPUT PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for ispw=1:3
    for ispr=1:3
        S=struct;
        for iang=1:73
            ang=-5*(iang-1);
            S.x_mc(iang)=0+500*cosd(ang);
            S.y_mc(iang)=0+500*sind(ang);
        end
        S.reftime='2020-01-01';
        S.endofsimulation='2024-01-01';
        S.Hso_in=1;                                                                % wave height [m]
        S.Hso=1;
        S.phiw0=270;                                                               % deep water wave angle [�N]
        %S.spread=0;                                                               % wave spreading [�] (wave_dir from range:  phiw0 +/- 0.5*spread)
        S.d=10;                                                                    % active profile height [m]
        S.b=1e6;                                                                   % CERC : coeff in simple cerc formula
        S.tc=0;                                                                    % switch for automatic time step
        S.dt=0.005;                                                                % time step [year]
        S.ds0=100;                                                                 % initial space step [m]
        S.nt=5000;                                                                 % number of timesteps
        S.struct=0;                                                                % switch for using hard structures
        S.twopoints=1;
        %S.spit_width=0; % width of tip of spit
        S.channel_width=0; %
        S.xlimits=[-1000 4000];
        S.ylimits=[-2500 2500];
        ntt=1;
        S.seaslope=0.01;
        S.landslope=0.05;
        S.seamin=-3;
        S.landmax=3;
        S.tide_interaction=false;
        S.dx=200;
        S.dy=200;
        S.Lx=10000;
        S.Ly=40000;
        S.zdeep=-10;
        S.zshallow=-2;
        S.slope=.002;
        S.outputdir=['Output\circle_dirspreading',num2str(ispw),num2str(ispr),'\'];
        S.plotinterval=10;
        S.fignryear=1;
        S.smoothfac=0.05;
        S.ld=1000;
        S.video=0;
        S.growth=0;
        S.spit_width=(ispw-1)*100;
        S.spread=(ispr-1)*90;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %% RUN SHORELINES MODEL
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        [S]=ShorelineS(S);
    end
end
