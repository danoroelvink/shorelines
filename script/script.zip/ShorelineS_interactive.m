addpath(genpath('..\functions_202201\'));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% MODEL INPUT PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S=struct;
S.reftime='2020-01-01';
S.endofsimulation='2080-01-01';
S.Hso=1;                                                                   % wave height [m]
S.phiw0=250;                                                               % deep water wave angle [�N]
S.phif=360;
S.spread=50;                                                               % wave spreading [�] (wave_dir from range:  phiw0 +/- 0.5*spread)
S.d=6;                                                                     % active profile height [m]
S.b=.5e6;                                                                  % CERC : coeff in simple cerc formula%
S.tc=0;                                                                    % adaptive time step
S.dt=1/365;                                                                % time step [yr]
S.ds0=100;                                                                 % initial space step [m]
S.struct=1;                                                                % switch for using hard structures
S.twopoints=1;
S.spit_width=50;                                                           % width of tip of spit
S.xlimits=[0 8000];
S.ylimits=[0 5000];
ntt=1;
S.seaslope=0.01;
S.landslope=0.05;
S.seamin=-3;
S.landmax=3;
S.tide_interaction=false;
S.dx=200;
S.dy=200;
S.Lx=10000;
S.Ly=40000;
S.zdeep=-10;
S.zshallow=-2;
S.slope=.002;
S.outputdir='Output\interactive\';
S.plotinterval=1;
S.storageinterval=1e6;
S.fignryear=1;
S.smoothfac=0.0;
S.ld=1000;
S.video=0;
S.x_hard=[];
S.y_hard=[];
S.usefill = 1;
S.debug=2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% RUN SHORELINES MODEL
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[S]=ShorelineS(S);
